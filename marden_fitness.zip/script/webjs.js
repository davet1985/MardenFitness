function DeselectAllMenuItems() {
  var elements = document.getElementsByClassName("menuitem");
  for (var i=0; i<elements.length; i++) {
    elements[i].style.background = "";
    elements[i].style.color = "white";
  };
}

function MenuItemSelect(pItemID) {
//  DeselectAllMenuItems();
  var lMenuItem = document.getElementById(pItemID);
  lMenuItem.style.background = "white";
  lMenuItem.style.color = "black";
};

function InitialPageLoad() {
  MenuItemSelect('home');
};